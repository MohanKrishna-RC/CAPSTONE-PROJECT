
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import tensorflow as tf
import os
from os import listdir

result_array = np.empty((0, 2049))
location = "/home/mohan/Downloads/CAPSTON_PROJECT1/bottleneck"
folder_list = listdir(location)

for folder in folder_list:
    folder_loc = location+'/'+folder
    file_list = listdir(folder_loc)
   
    for i in file_list:
     
       
        file_list_loc = folder_loc+'/'+i
        data = pd.read_csv(file_list_loc, header= None, sep= ',' )
        data['labels']=str(folder)
        result_array = np.append(result_array,data,axis= 0)
       
       
    print('Done '+str(folder))


# In[2]:


np.random.seed(0)


# In[3]:


data.head()


# In[4]:


data['is_train'] = np.random.uniform(0, 1, len(data)) <= 0.75


# In[5]:


data.head()


# In[6]:


#data['labels'] = pd.Categorical.from_codes(data.target, data.target_names)


# In[7]:


train, test = data[data['is_train']==True], data[data['is_train']==False]


# In[8]:


result_array.shape


# In[9]:


result_array_y= result_array[:,2048]
#result_array_y.shape


# In[10]:


#pd.DataFrame(result_array).to_csv('result_array.csv')


# In[11]:


result_array_x= np.delete(result_array,[2048],1)


# In[12]:


from sklearn import preprocessing
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split


# In[13]:


X_train, X_test, y_train, y_test = train_test_split(result_array_x,result_array_y,test_size=0.30, random_state=1234)


# In[16]:


from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification


# In[19]:


X = X_train
y = y_train
#clf = RandomForestClassifier(n_jobs=2, random_state=0)
#clf.fit(train[features], y)
clf = RandomForestClassifier(n_estimators=300)
clf.fit(X, y)


# In[20]:


clf.score(X_test,y_test)

