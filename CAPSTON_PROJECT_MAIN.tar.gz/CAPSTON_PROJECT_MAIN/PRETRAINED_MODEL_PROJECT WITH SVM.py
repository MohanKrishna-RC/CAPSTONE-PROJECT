
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
import tensorflow as tf
import os
from os import listdir
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC

result_array = np.empty((0, 2049))
location = "/home/mohan/Downloads/CAPSTON_PROJECT1/bottleneck"
folder_list = listdir(location)

for folder in folder_list:
    folder_loc = location+'/'+folder
    file_list = listdir(folder_loc)
   
    for i in file_list:
     
       
        file_list_loc = folder_loc+'/'+i
        data = pd.read_csv(file_list_loc, header= None, sep= ',' )
        data['labels']=str(folder)
        result_array = np.append(result_array,data,axis= 0)
       
       
    print('Done '+str(folder))


# In[2]:


#data['labels'] = pd.Categorical.from_codes(, iris.target_names)


# In[3]:


result_array.shape


# In[4]:


result_array_y= result_array[:,2048]
#result_array_y.shape


# In[5]:


#pd.DataFrame(result_array).to_csv('result_array.csv')


# In[6]:


result_array_x= np.delete(result_array,[2048],1)


# In[7]:


#le =LabelEncoder()
#le.fit(df_train)
#le.transform(df_train)
#data1.apply(LabelEncoder().fit_transform)


# # Splitting into train and test

# In[8]:


X_train, X_test, y_train, y_test = train_test_split(result_array_x,result_array_y,test_size=0.30, random_state=1234)


# # Loading the SVM MODEL

# In[9]:


clf = LinearSVC(random_state=0,max_iter=500)
clf.fit( X_train,y_train)


# In[10]:


clf.score(X_test,y_test)

