
# coding: utf-8

# In[1]:


import tensorflow as tf
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import cv2
from os import listdir
from os.path import isfile, join


# In[2]:


data = pd.read_csv('/home/mohan/Downloads/CAPSTON_PROJECT1/labels.csv',delimiter=',')
print(data.shape)
data.head()


# In[3]:


x=data['breed']
x = np.array(x)
x


# In[ ]:


#This will get all the files in a folder in onlyfiles.
#And then it will read them all and store them in the array images.


# In[4]:



mypath='/home/mohan/Downloads/CAPSTON_PROJECT1/train'
onlyfiles = [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
#images = np.empty(len(onlyfiles), dtype=object)
classes = []
images = []
for n in range(len(onlyfiles)):
    image = cv2.imread( join(mypath,onlyfiles[n]))
    classes.append(x[n])
    small = cv2.resize(image, (0,0), fx=1, fy=1)
    resized_image= cv2.resize(small, (128, 128)) 
    images.append(resized_image)


# In[1]:


# Converting BGR to RGB images


# IF WE APPLY CV2 TO READ THE IMAGES THEN WE WILL GET THE IMAGES IN "BGR" FORM, BUT IN NUMPY WE WILL GET "RGB" IMAGES. SO WE NEED TO CONVERT THE IMAGE TO RGB

# In[5]:


inputs = []
for i in range(10222):
     inputs.append(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB))


# In[6]:


img= images
img = np.array(img)
img.shape


# In[7]:


def plot_images(images, classes):
    assert len(images) == len(classes) == 9
    
    # Create figure with 3x3 sub-plots.
    fig, axes = plt.subplots(3, 3,figsize=(60,60),sharex=True)
    fig.subplots_adjust(hspace=0.3, wspace=0.3)
   
    for i, ax in enumerate(axes.flat):
        # Plot image.
        
        ax.imshow(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB).reshape(128,128,3), cmap='hsv')    
        xlabel = "Breed: {0}".format(classes[i])
    
        # Show the classes as the label on the x-axis.
        ax.set_xlabel(xlabel)
        ax.xaxis.label.set_size(60)
        # Remove ticks from the plot.
        ax.set_xticks([])
        ax.set_yticks([])
    
    # Ensure the plot is shown correctly with multiple plots
    # in a single Notebook cell.
    
    plt.show()


# # Rotation

# In[8]:


#batch_size = 32
images_to_show1= [np.random.randint(0, len(img)) for p in range(0,2000)]
Rotation= []
Rotation_class =[]
for i in images_to_show1:
    rows, columns, channels = img[i].shape 
    R = cv2.getRotationMatrix2D((columns/2, rows/2), 370, 1) 
    Rotation.append(cv2.warpAffine(img[i], R, (columns, rows)))
    Rotation_class.append(classes[i])


# In[9]:


##plt.imshow(Rotation[4])
#plt.axis('off')
#plt.show()


# # Rotation Resize

# In[10]:


#batch_size = 32
images_to_show2= [np.random.randint(0, len(img)) for p in range(0,2000)]
Rot_Resize = []
Rot_Resize_class = []
for i in images_to_show2:
    rows, columns, channels = img[i].shape 
    R = cv2.getRotationMatrix2D((columns/2, rows/2), 370, 1) 
    Rot_Resize.append (cv2.resize( img[i], None, fx=0.5, fy=1.5, interpolation=cv2.INTER_AREA ))
    Rot_Resize_class.append(classes[i])


# In[11]:


#plt.imshow(Rot_Resize[4])
#plt.axis('off')
#plt.show()


# # Transform to one point

# In[12]:


images_to_show4= [np.random.randint(0, len(img)) for p in range(0,2000)]
Transform = []
Transform_class =[]
for i in range(300):
    rows, columns, channels = img[i].shape    
    point1 = np.float32([[50, 100], [200, 100], [100, 300]])
    point2 = np.float32([[100, 150], [300, 150], [200, 400]])
    
    A = cv2.getAffineTransform(point1, point2)
    
    #print(A)
    Transform.append(cv2.warpAffine(img[i], A, (columns, rows)))
    Transform_class.append(classes[i])


# In[13]:


#plt.imshow(Transform[5])
#plt.axis('off')
#plt.show()


# # Laplacian

# In[14]:


images_to_show7= [np.random.randint(0, len(img)) for p in range(0,5000)]
Laplacian =[]
Laplacian_class = []
for i in images_to_show7:
    rows, columns, channels = img[i].shape  
    Laplacian.append(cv2.Laplacian(img[i], -1, ksize=29, scale=1, delta=0, 
                          borderType=cv2.BORDER_DEFAULT))
    
    Laplacian_class.append(classes[i]) 
    #titles = ['Original', 'Edges']


# In[15]:


#plt.imshow(Laplacian[3])
#plt.axis('off')
#plt.show()


# # Flipping

# In[16]:


image_to_show8 = [np.random.randint(0, len(images)) for p in range(0,5000)]
flip_input = []
flip_class =[]
for i in image_to_show8:
    flip_input.append(cv2.flip(inputs[i],1))
    flip_class.append(classes[i])


# In[17]:


#plt.imshow(flip_input[99])
#plt.axis('off')
#plt.show()


# # Erosion

# In[18]:


image_to_show9 = [np.random.randint(0, len(images)) for p in range(0,5000)]
kernel_rect = cv2.getStructuringElement(cv2.MORPH_RECT,(5,5))
kernel_ellipse = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
kernel_crossed = cv2.getStructuringElement(cv2.MORPH_CROSS,(5,5))


# In[19]:


Erosion_input =[]
Erosion_class=[]
for i in image_to_show9:
    Erosion_input.append(cv2.erode(inputs[i],kernel_rect,iterations=1))
    Erosion_class.append(classes[i])


# In[20]:


#plt.imshow(Erosion_input[87])
#plt.axis('off')
#plt.show()


# In[21]:


x = np.array(images[:1024],dtype="float32")
y1 = np.array(classes[:1024])
y = np.array(pd.get_dummies(y1,dtype="float32"))

x_validation = np.array(images[1024:2000],dtype="float32")
y_validation1 = np.array(classes[1024:2000])
y_validation = np.array(pd.get_dummies(y_validation1,dtype="float32"))
x.shape


# # CONVERTING INTO ARRAY

# In[22]:


Transform_arr = np.array(Transform)
Rotation_arr = np.array(Rotation)
Rot_Resize_arr = np.array(Rotation)
Erosion_input_arr = np.array(Erosion_input)
flip_input_arr = np.array(flip_input)
Laplacian_arr = np.array(Laplacian)


# # EXTENDING ALL THE CLASS_BREEDS

# In[23]:


Rotation_class.extend(Rot_Resize_class)
Rotation_class.extend(Erosion_class)
Rotation_class.extend(Laplacian_class)
Rotation_class.extend(flip_class)
Rotation_class.extend(Transform_class)


# In[24]:


print(len(Rotation_class))


# # Concatenating all the arrays

# In[25]:


final=np.concatenate((Rotation_arr,Rot_Resize_arr,Transform_arr,Erosion_input_arr,flip_input_arr,Laplacian_arr),axis=0)


# In[26]:


print(final.shape)
id = np.arange(19300)
print(len(id))


# # Writing all the images into a folder

# In[27]:


final1=[]
for i in range(final.shape[0]):
    final1.append(cv2.imwrite('/home/mohan/Downloads/CAPSTON_PROJECT1/augmented_img/{}.jpg'.format(i),final[i]))


# # Creating a dataframe using all classes and convert to .csv

# In[28]:


#df=pd.DataFrame(Rotation_class)

df1 = pd.DataFrame({'id':id, 'breed':Rotation_class},columns=['id','breed'])

df1.to_csv('/home/mohan/Downloads/CAPSTON_PROJECT1/breed_classify'+'1.csv', index=False)


# In[29]:


#df.to_csv('/home/mohan/Downloads/CAPSTONE PROJECT1/breed_classify'+'1.csv')

