
# coding: utf-8

# In[1]:


import tensorflow as tf
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import cv2
from os import listdir
from os.path import isfile, join


# In[2]:


data = pd.read_csv('/home/mohan/Downloads/CAPSTON_PROJECT1/labels.csv',delimiter=',')
print(data.shape)
data.head()
#df = np.asarray(data)
#df.shape


# In[3]:


x=data['breed']
x = np.array(x)
x


# In[ ]:


# The below line will get all the files in a folder in onlyfiles.
# And then it will read them all and store them in the array images.


# In[4]:


mypath='/home/mohan/Downloads/CAPSTON_PROJECT1/train'
onlyfiles = [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
#images = np.empty(len(onlyfiles), dtype=object)
classes = []
images = []
for n in range(len(onlyfiles)):
    image = cv2.imread( join(mypath,onlyfiles[n]))
    classes.append(x[n])
    small = cv2.resize(image, (0,0), fx=1, fy=1)
    resized_image= cv2.resize(small, (128, 128)) 
    images.append(resized_image)


# # Converting BGR TO RGB  images

# IF WE APPLY CV2 TO READ THE IMAGES THEN WE WILL GET THE IMAGES IN "BGR" FORM, BUT IN NUMPY WE WILL GET "RGB" IMAGES. SO WE NEED TO CONVERT THE IMAGE TO RGB

# In[1]:


inputs = []
for i in range(10222):
     inputs.append(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB))


# In[6]:


img= images
img = np.array(img)
img.shape


# In[7]:


def plot_images(images, classes):
    assert len(images) == len(classes) == 9
    
    # Create figure with 3x3 sub-plots.
    fig, axes = plt.subplots(3, 3,figsize=(60,60),sharex=True)
    fig.subplots_adjust(hspace=0.3, wspace=0.3)
   
    for i, ax in enumerate(axes.flat):
        # Plot image.
        
        ax.imshow(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB).reshape(128,128,3), cmap='hsv')    
        xlabel = "Breed: {0}".format(classes[i])
    
        # Show the classes as the label on the x-axis.
        ax.set_xlabel(xlabel)
        ax.xaxis.label.set_size(60)
        # Remove ticks from the plot.
        ax.set_xticks([])
        ax.set_yticks([])
    
    # Ensure the plot is shown correctly with multiple plots
    # in a single Notebook cell.
    
    plt.show()


# # Blurring Filter

# In[8]:


images_to_show= [np.random.randint(0, len(img)) for p in range(0,1000)]
gaussian_input = []
gaussian_class =[]
for i in images_to_show: 
    gaussian_input.append(cv2.GaussianBlur(img[i], (37, 37), 0))
    gaussian_class.append(classes[i])


# In[10]:


images_to_show1= [np.random.randint(0, len(img)) for p in range(0,1000)]
Box_Filter =[]
Box_Filter_class =[]
for i in images_to_show1:
    Box_Filter.append(cv2.boxFilter(img[i], -1, (53, 53)))
    Box_Filter_class.append(classes[i])


# In[12]:


images_to_show2= [np.random.randint(0, len(img)) for p in range(0,1000)]
blur_input =[]
blur_class =[]
for i in images_to_show2: 
    blur_input.append(cv2.blur(img[i], (13, 13)))
    blur_class.append(classes[i])


# # Converting to Arrays

# In[ ]:


blur_arr = np.array(blur_input)
Box_Filter_arr = np.array(Box_Filter)
gaussian_arr = np.array(gaussian_input)


# # EXTENDING ALL THE CLASS_BREEDS

# In[14]:


Box_Filter_class.extend(gaussian_class)
Box_Filter_class.extend(blur_class)


# # Concatenating all the arrays

# In[16]:


final=np.concatenate((gaussian_arr,blur_arr,Box_Filter_arr),axis=0)


# In[17]:


id = np.arange(19300, 22300)


# # Writing all the images into a folder

# In[18]:


final1=[]
for i in range(final.shape[0]):
    j = i + 19300
    final1.append(cv2.imwrite('/home/mohan/Downloads/CAPSTON_PROJECT1/augmented_img/{}.jpg'.format(j),final[i]))


# # Creating a dataframe using all classes and convert to .csv

# In[20]:


df2 = pd.DataFrame({'id':id, 'breed':Box_Filter_class},columns=['id','breed'])

df2.to_csv('/home/mohan/Downloads/CAPSTON_PROJECT1/breed_classify'+'2.csv', index=False)


# In[ ]:


#df.to_csv('/home/mohan/Downloads/CAPSTONE PROJECT1/breed_classify'+'2.csv')

