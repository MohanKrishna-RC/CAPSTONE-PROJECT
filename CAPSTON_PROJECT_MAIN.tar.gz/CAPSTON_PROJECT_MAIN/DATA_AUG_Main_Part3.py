
# coding: utf-8

# In[1]:


import tensorflow as tf
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os
import cv2
from os import listdir
from os.path import isfile, join


# In[2]:


data = pd.read_csv('/home/mohan/Downloads/CAPSTON_PROJECT1/labels.csv',delimiter=',')
print(data.shape)
data.head()
#df = np.asarray(data)
#df.shape


# In[3]:


x=data['breed']
x = np.array(x)
x


# In[4]:


#This will get all the files in a folder in onlyfiles.
#And then it will read them all and store them in the array images.

mypath='/home/mohan/Downloads/CAPSTON_PROJECT1/train'
onlyfiles = [ f for f in listdir(mypath) if isfile(join(mypath,f)) ]
#images = np.empty(len(onlyfiles), dtype=object)
classes = []
images = []
for n in range(len(onlyfiles)):
    image = cv2.imread( join(mypath,onlyfiles[n]))
    classes.append(x[n])
    small = cv2.resize(image, (0,0), fx=1, fy=1)
    resized_image= cv2.resize(small, (128, 128)) 
    images.append(resized_image)


# In[5]:


inputs = []
for i in range(10222):
     inputs.append(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB))


# IF WE APPLY CV2 TO READ THE IMAGES THEN WE WILL GET THE IMAGES IN "BGR" FORM, BUT IN NUMPY WE WILL GET "RGB" IMAGES. SO WE NEED TO CONVERT THE IMAGE TO RGB

# In[6]:


img= images
img = np.array(img)
img.shape


# In[7]:


def plot_images(images, classes):
    assert len(images) == len(classes) == 9
    
    # Create figure with 3x3 sub-plots.
    fig, axes = plt.subplots(3, 3,figsize=(60,60),sharex=True)
    fig.subplots_adjust(hspace=0.3, wspace=0.3)
   
    for i, ax in enumerate(axes.flat):
        # Plot image.
        
        ax.imshow(cv2.cvtColor(images[i], cv2.COLOR_BGR2RGB).reshape(128,128,3), cmap='hsv')    
        xlabel = "Breed: {0}".format(classes[i])
    
        # Show the classes as the label on the x-axis.
        ax.set_xlabel(xlabel)
        ax.xaxis.label.set_size(60)
        # Remove ticks from the plot.
        ax.set_xticks([])
        ax.set_yticks([])
    
    # Ensure the plot is shown correctly with multiple plots
    # in a single Notebook cell.
    
    plt.show()


# # THRESHOLD FILTER

# In[8]:


images_to_show3= [np.random.randint(0, len(img)) for p in range(0,1000)]
o1 = []
o1_class =[]
for i in images_to_show3:    
    th = 127
    max_val = 255
    ret,TH= cv2.threshold(img[i], th, max_val, cv2.THRESH_BINARY)
    o1.append(TH)
    o1_class.append(classes[i])


# In[10]:


images_to_show4= [np.random.randint(0, len(img)) for p in range(0,1000)]
o2 =[]
o2_class =[]
for i in images_to_show4: 
    th = 127
    max_val = 255
    ret,THI= cv2.threshold(img[i], th, max_val, cv2.THRESH_BINARY_INV)
    o2.append(THI)
    o2_class.append(classes[i])


# In[12]:


images_to_show5= [np.random.randint(0, len(img)) for p in range(0,1000)]
o3 =[]
o3_class =[]
for i in images_to_show5: 
    th = 127
    max_val = 255
    ret,THZ = cv2.threshold(img[i], th, max_val, cv2.THRESH_TOZERO)
    o3.append(THZ)
    o3_class.append(classes[i])


# In[14]:


images_to_show6= [np.random.randint(0, len(img)) for p in range(0,1000)]
o4 =[]
o4_class =[]
for i in images_to_show6:    
    th = 127
    max_val = 255
    ret,THZI=cv2.threshold(img[i], th, max_val, cv2.THRESH_TOZERO_INV)
    o4.append(THZI)
    o4_class.append(classes[i])


# In[16]:


images_to_show7= [np.random.randint(0, len(img)) for p in range(0,1000)]
o5 =[]
o5_class =[]
for i in images_to_show7:    
    th = 127
    max_val = 255
    ret,TT = cv2.threshold(img[i], th, max_val, cv2.THRESH_TRUNC)
    o5.append(TT)
    o5_class.append(classes[i])


# # CONVERTING INTO ARRAY

# In[ ]:


o1_arr = np.array(o1)
o2_arr = np.array(o2)
o3_arr = np.array(o3)
o4_arr = np.array(o4)
o5_arr = np.array(o5)


# # EXTENDING ALL THE CLASS_BREEDS

# In[18]:


o1_class.extend(o2_class)
o1_class.extend(o3_class)
o1_class.extend(o4_class)
o1_class.extend(o5_class)


# # Concatenating all the arrays

# In[20]:


final=np.concatenate((o1_arr,o2_arr,o3_arr,o4_arr,o5_arr),axis=0)


# In[21]:


id = np.arange(22300, 27300)


# # Writing all the images into a folder

# In[22]:


final1=[]
for i in range(final.shape[0]):
    j = i + 22300
    final1.append(cv2.imwrite('/home/mohan/Downloads/CAPSTON_PROJECT1/augmented_img/{}.jpg'.format(j),final[i]))
len(final1)


# # Creating a dataframe using all classes and convert to .csv

# In[23]:


df3 = pd.DataFrame({'id':id, 'breed':o1_class},columns=['id','breed'])

df3.to_csv('/home/mohan/Downloads/CAPSTON_PROJECT1/breed_classify'+'3.csv', index=False)


# In[24]:


#df.to_csv('/home/mohan/Downloads/CAPSTONE PROJECT1/breed_classify'+'2.csv')

